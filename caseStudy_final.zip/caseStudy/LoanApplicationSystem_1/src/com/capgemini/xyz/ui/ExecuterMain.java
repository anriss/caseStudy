package com.capgemini.xyz.ui;

import java.math.BigInteger;
import java.util.Scanner;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.exceptions.InvalidAddressException;
import com.capgemini.xyz.exceptions.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;



public class ExecuterMain {
public static void main(String args[]) 
{
	try{
ILoanService loanservice= new LoanService();
Scanner sc = new Scanner(System.in);
System.out.println("Enter name:");
String name=sc.next();
System.out.println("Enter address");
String address = sc.next();
System.out.println("Enter email");
String email=sc.next();
	Customer customer= new Customer(name,address,email);
loanservice.validateCustomer(customer);
	}
	catch(InvalidAddressException|InvalidNameException|InvalidEmailException e){
		e.getMessage();
	}

}
}

package com.capgemini.xyz.service;

import java.util.List;

import javax.naming.InvalidNameException;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.exceptions.InvalidAddressException;
import com.capgemini.xyz.exceptions.InvalidEmailException;

public interface ILoanService {
public long applyLoan(Loan loan);
public Customer validateCustomer(Customer customer)throws InvalidNameException,InvalidAddressException,InvalidEmailException;
public long insertCust(Customer customer);
public double calculateEMI(double amount,int duration);
List<Customer>getCustomerDetails();
List<Loan>getLoanDetails();
}

package com.capgemini.xyz.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.dao.ILoanDAO;
import com.capgemini.xyz.dao.LoanDAO;
import com.capgemini.xyz.exceptions.InvalidAddressException;
import com.capgemini.xyz.exceptions.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;


public class LoanService implements ILoanService{
	ILoanDAO loanDAO= new LoanDAO();
	@Override
	public long applyLoan(Loan loan) {
		return loanDAO.applyLoan(loan);
	}

	@Override
	public Customer validateCustomer(Customer customer){
		Pattern pattern= Pattern.compile("[A-Z][a-z]*]");
		Pattern emailPattern=Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher customerMatcher = pattern.matcher(customer.getCustomerName());
		Matcher addressMatcher=pattern.matcher(customer.getAddress());
		Matcher emailMatcher=pattern.matcher(customer.getEmail());
		try{
			if(customerMatcher.find()==false)
			{
				throw new InvalidNameException("Enter name in the correct format");
			}
			else if(addressMatcher.find()==false)
			{
				throw new InvalidAddressException("Enter address in the correct format");
			}
			else if(emailMatcher.find()==false)
			{
				throw new InvalidEmailException("Enter valid email address");
			}
		}
		catch (InvalidNameException|InvalidAddressException|InvalidEmailException e) {
			e.printStackTrace();
		}	return customer;
	}


	@Override
	public long insertCust(Customer customer) {
		return loanDAO.insertCust(customer);
	}

	@Override
	public double calculateEMI(double amount, int duration) {
		double loanEMI=amount*((0.095)*(1+0.095)*duration)/((1+0.095)*duration-1);
		return loanEMI;
	}

	@Override
	public List<Customer> getCustomerDetails() {
		return loanDAO.findOneCustomer();
	}

	@Override
	public List<Loan> getLoanDetails(){
		return loanDAO.findOneLoan();
	}

}

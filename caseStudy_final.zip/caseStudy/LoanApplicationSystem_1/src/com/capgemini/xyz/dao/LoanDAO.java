package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.util.CollectionUtil;

public class LoanDAO implements ILoanDAO{


	HashMap<Integer,Loan>loanEntry=new HashMap<>();
	HashMap<Integer, Customer>customerEntry=new HashMap<>();
	
	@Override
	public long applyLoan(Loan loan) {
		loan.setCutomerId(CollectionUtil.getCUSTOMER_ID());
		loan.setLoanId(CollectionUtil.getLOAN_ID());
		this.loanEntry.put(CollectionUtil.getLOAN_ID(), loan);
		return loan.getLoanId();
	}

	@Override
	public long insertCust(Customer customer) {
		customer.setCusttomerId(CollectionUtil.getCUSTOMER_ID());
		this.customerEntry.put(CollectionUtil.getCUSTOMER_ID(), customer);
		return customer.getCustomerId();
	}

	@Override
	public List<Customer> findOneCustomer() {
		return (List<Customer>) this.customerEntry;
	}

	@Override
	public List<Loan> findOneLoan() {
		return (List<Loan>) this.loanEntry;
	}
	

}

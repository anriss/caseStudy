package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;

public interface ILoanDAO {
HashMap<Integer,Loan>loanEntry=null;
HashMap<Integer,Customer>customerEntry=null;
List<Customer>findOneCustomer();
List<Loan>findOneLoan();
long applyLoan(Loan loan);
long insertCust(Customer customer);
}

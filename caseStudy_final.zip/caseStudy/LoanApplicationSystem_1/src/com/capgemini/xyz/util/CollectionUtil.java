package com.capgemini.xyz.util;

import java.util.HashMap;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;

public class CollectionUtil {

public static int CUSTOMER_ID=(int)Math.random()*1000;
public static int LOAN_ID=(int)Math.random()*1000;
public static int getCUSTOMER_ID() {
	return CUSTOMER_ID;
}
public static int getLOAN_ID() {
	return LOAN_ID;
}


}

package com.capgemini.xyz.beans;

public class Loan {
private long loanId;
private double loanAmount;
private long cutomerId;

public Loan(){}

public Loan(long loanId, double loanAmount, long cutomerId) {
	super();
	this.loanId = loanId;
	this.loanAmount = loanAmount;
	this.cutomerId = cutomerId;
}

public long getLoanId() {
	return loanId;
}

public void setLoanId(long loanId) {
	this.loanId = loanId;
}

public double getLoanAmount() {
	return loanAmount;
}

public void setLoanAmount(double loanAmount) {
	this.loanAmount = loanAmount;
}

public long getCutomerId() {
	return cutomerId;
}

public void setCutomerId(long cutomerId) {
	this.cutomerId = cutomerId;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + (int) (cutomerId ^ (cutomerId >>> 32));
	long temp;
	temp = Double.doubleToLongBits(loanAmount);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	result = prime * result + (int) (loanId ^ (loanId >>> 32));
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Loan other = (Loan) obj;
	if (cutomerId != other.cutomerId)
		return false;
	if (Double.doubleToLongBits(loanAmount) != Double.doubleToLongBits(other.loanAmount))
		return false;
	if (loanId != other.loanId)
		return false;
	return true;
}

@Override
public String toString() {
	return "Loan [loanId=" + loanId + ", loanAmount=" + loanAmount + ", cutomerId=" + cutomerId + "]";
}


}

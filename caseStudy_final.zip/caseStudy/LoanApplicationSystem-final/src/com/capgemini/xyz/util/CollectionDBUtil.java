package com.capgemini.xyz.util;

import java.util.HashMap;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;

public class CollectionDBUtil {
	/*
	 * public static HashMap<Integer,Customer>customerEntry = new HashMap<Integer,Customer>(); 
	 * public static HashMap<Integer,Loan>loanEntry= new HashMap<Integer, Loan>();
	 */
	
	/*
	 * public HashMap<Integer, Customer> getCustomerEntry() { return customerEntry;
	 * } public HashMap<Integer, Loan> getLoanEntry() { return loanEntry; }
	 */
	public static long CUSTOMER_ID=(int)(Math.random()*1000+101);
	public static long LOAN_ID=(int)(Math.random()*1000+101);
	public static long getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}
	public static long getLOAN_ID() {
		return LOAN_ID;
	}
	
}

package com.capgemini.xyz.ui;

import java.security.Provider.Service;
import java.util.Scanner;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.dao.LoanDAO;
import com.capgemini.xyz.exceptions.InvalidAddressException;
import com.capgemini.xyz.exceptions.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.util.CollectionDBUtil;



public class ExecuterMain {
	private static Scanner sc;

	public static void main(String args[]) throws InvalidNameException {

		ILoanService loanservice= new LoanService();
		Scanner sc = new Scanner(System.in);
		System.out.println("1. Register Customer");
		System.out.println("2. exit");
		try {
			int choice=sc.nextInt();
			switch(choice) {
			case 1: 
				System.out.println("Enter name:");
				String name=sc.next();
				System.out.println("Enter address");
				String address = sc.next();
				System.out.println("Enter email");
				String email=sc.next();
				Customer customer= new Customer(name,address,email);
				loanservice.validateCustomer(customer);
				System.out.println("Customer information saved successfully");
				System.out.println("Your customer id is: "+loanservice.insertCust(customer));
				System.out.println("Do you want to apply for loan?");	
				String answer=sc.next();
				if(answer.equalsIgnoreCase("yes"))
				{
					System.out.println("Enter loan amount");
					double loanAmount=sc.nextDouble();
					System.out.println("Enter the loan duration in years");
					int duration=sc.nextInt();
					System.out.println("For loan amount "+loanAmount+ " and "+duration+"years duration");
					System.out.println("Your EMI per month will be :"+loanservice.calculateEMI(loanAmount, duration));
					System.out.println("Do you want to apply for loan?");
					String loanAnswer=sc.next();
					if(loanAnswer.equalsIgnoreCase(loanAnswer))
					{
						Loan loan=new Loan(loanAmount, duration);
						loanservice.applyLoan(loan);
						System.out.println("Your loan request is generated");
						System.out.println("Your loan id is :"+loan.getLoanId());
						System.out.println(loanservice.getCustomerDetails(customer.getCutomerId()));
						System.out.println(loanservice.getLoanDetails(loan.getLoanId()));
					}
				}
				else
				{
					System.out.println(loanservice.validateCustomer(customer));
				}
				break;
			case 2: 
				System.exit(0);
				break;

			default: System.out.println("Enter valid choice");
			break;
			}
		}catch( InvalidNameException|InvalidAddressException|InvalidEmailException e) {
			e.printStackTrace();//for Error use multiple catch and use "e.getMessage();"
		}

	}
}

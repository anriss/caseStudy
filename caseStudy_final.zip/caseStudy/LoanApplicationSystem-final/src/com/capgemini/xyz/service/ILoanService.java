package com.capgemini.xyz.service;

import java.util.List;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.exceptions.InvalidAddressException;
import com.capgemini.xyz.exceptions.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;

public interface ILoanService {
	public long applyLoan(Loan loan);
	public Customer validateCustomer(Customer customer)throws InvalidNameException,InvalidAddressException,InvalidEmailException;
	public long insertCust(Customer customer);
	public double calculateEMI(double amount,int duration);
	Customer getCustomerDetails(long customerId);
	Loan getLoanDetails(long loanId);
}

package com.capgemini.xyz.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.dao.ILoanDAO;
import com.capgemini.xyz.dao.LoanDAO;
import com.capgemini.xyz.exceptions.InvalidAddressException;
import com.capgemini.xyz.exceptions.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;

public class LoanService implements ILoanService{
	ILoanDAO loanDAO= new LoanDAO();
	@Override
	public long applyLoan(Loan loan) {
		return loanDAO.applyLoan(loan);
	}

	@Override
	public Customer validateCustomer(Customer customer) throws InvalidNameException, InvalidAddressException, InvalidEmailException{
		String name=customer.getCustomerName(); 
		String address=customer.getAddress();
		String email=customer.getEmail(); 
		Pattern pattern=Pattern.compile("[A-Z][a-z]"); 
		Pattern emailPattern=Pattern.compile("^[_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*\\.(([0-9]{1,3})|([a-zA-Z]{2,3})|(aero|coop|info|museum|name))$"); 
		Matcher customerMatcher = pattern.matcher(name); 
		Matcher addressMatcher=pattern.matcher(address);
		Matcher emailMatcher=emailPattern.matcher(email); 
		
			if(customerMatcher.find()==false) { 
				throw new  InvalidNameException("First character of the name must be captial"); 
			}
			else if(addressMatcher.find()==false) {
				throw new  InvalidAddressException("First character of the address must be captial"); 
			} 
			else if(emailMatcher.find()==false){
				throw new InvalidEmailException("Enter valid email address");
			}
		return customer;	
		}
	
	

	@Override
	public long insertCust(Customer customer) {
		return loanDAO.insertCust(customer);
	}

	@Override
	public double calculateEMI(double amount, int duration) {
		double loanEMI=amount*((0.095)*(1+0.095)*duration)/((1+0.095)*duration-1);
		return loanEMI;
	}

	@Override
	public Customer getCustomerDetails(long customerId) {
		return loanDAO.findOneCustomer(customerId);
	}

	@Override
	public Loan getLoanDetails(long loanId){
		return loanDAO.findOneLoan(loanId);
	}


}

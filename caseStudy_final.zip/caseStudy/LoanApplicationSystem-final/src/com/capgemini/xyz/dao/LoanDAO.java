package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;
import com.capgemini.xyz.util.CollectionDBUtil;

public class LoanDAO implements ILoanDAO {
	@Override
	public long applyLoan(Loan loan) {
		loan.setLoanId(CollectionDBUtil.getLOAN_ID());
		loan.setCustId(CollectionDBUtil.getCUSTOMER_ID());
		this.loanEntry.put(loan.getLoanId(), loan);
		return loan.getLoanId();
	}
	public HashMap<Long,Loan>loanEntry = new HashMap<Long, Loan>();

	@Override
	public long insertCust(Customer customer) {
		customer.setCutomerId(CollectionDBUtil.getCUSTOMER_ID());
		this.customerEntry.put(customer.getCutomerId(), customer);
		return customer.getCutomerId();
	}

	public static HashMap<Long,Customer>customerEntry = new HashMap<>();

	/*@Override
	public HashMap<Integer, Customer> customerEntry(Customer cust) {
	cust.setCutomerId(CollectionDBUtil.getCUSTOMER_ID());
	CollectionDBUtil.customerEntry.put(CollectionDBUtil.getCUSTOMER_ID(), cust);
		return CollectionDBUtil.customerEntry;
	}

	@Override
	public HashMap<Integer, Loan> loanEntr {
		loan.setCustId(CollectionDBUtil.getCUSTOMER_ID());
		loan.setLoanId(CollectionDBUtil.getLOAN_ID());
		CollectionDBUtil.loanEntry.put(CollectionDBUtil.getLOAN_ID(), loan);
		return CollectionDBUtil.loanEntry;
	}*/

	@Override
	public Customer findOneCustomer(long customerId) {
		Customer customerDetails = this.customerEntry.get(customerId);
		return customerDetails;
	}

	@Override
	public Loan findOneLoan(long loanId) {
		Loan loan = this.loanEntry.get(loanId);
		return loan;
	}


}


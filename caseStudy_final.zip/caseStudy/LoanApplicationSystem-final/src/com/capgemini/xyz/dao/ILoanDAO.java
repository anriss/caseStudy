package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.xyz.beans.Customer;
import com.capgemini.xyz.beans.Loan;

public interface ILoanDAO {
public HashMap<Long,Customer>customerEntry=null;
public HashMap<Long,Loan>loanEntry=null;
public long applyLoan(Loan loan);
public long insertCust(Customer customer);
public Customer findOneCustomer(long customerId);
public Loan findOneLoan(long loanId);
}

package com.capgemini.xyz.exceptions;

public class InvalidAddressException extends Exception {

	public InvalidAddressException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

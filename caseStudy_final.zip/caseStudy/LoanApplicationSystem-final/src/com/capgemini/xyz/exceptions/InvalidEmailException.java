package com.capgemini.xyz.exceptions;

public class InvalidEmailException extends Exception {

	public InvalidEmailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



}

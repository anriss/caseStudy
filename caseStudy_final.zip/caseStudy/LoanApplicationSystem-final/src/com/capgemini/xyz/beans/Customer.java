package com.capgemini.xyz.beans;

public class Customer {
private long cutomerId;
private String customerName;
private String address;
private long mobile;
private String email;

public Customer() {}

public Customer(long cutomerId, String customerName, String address, long mobile, String email) {
	super();
	this.cutomerId = cutomerId;
	this.customerName = customerName;
	this.address = address;
	this.mobile = mobile;
	this.email = email;
}

public Customer(String Customername, String address, String email) {
	this.customerName=Customername;
	this.address=address;
	this.email=email;
}

public long getCutomerId() {
	return cutomerId;
}

public void setCutomerId(long cutomerId) {
	this.cutomerId = cutomerId;
}

public String getCustomerName() {
	return customerName;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public long getMobile() {
	return mobile;
}

public void setMobile(long mobile) {
	this.mobile = mobile;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((address == null) ? 0 : address.hashCode());
	result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
	result = prime * result + (int) (cutomerId ^ (cutomerId >>> 32));
	result = prime * result + ((email == null) ? 0 : email.hashCode());
	result = prime * result + (int) (mobile ^ (mobile >>> 32));
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (address == null) {
		if (other.address != null)
			return false;
	} else if (!address.equals(other.address))
		return false;
	if (customerName == null) {
		if (other.customerName != null)
			return false;
	} else if (!customerName.equals(other.customerName))
		return false;
	if (cutomerId != other.cutomerId)
		return false;
	if (email == null) {
		if (other.email != null)
			return false;
	} else if (!email.equals(other.email))
		return false;
	if (mobile != other.mobile)
		return false;
	return true;
}

@Override
public String toString() {
	return "Customer [cutomerId=" + cutomerId + ", customerName=" + customerName + ", address=" + address + ", mobile="
			+ mobile + ", email=" + email + "]";
}


}
